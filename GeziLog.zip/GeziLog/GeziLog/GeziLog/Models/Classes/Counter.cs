﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GeziLog.Models.Classes
{
    public class Counter
    {
        public int CounterID { get; set; }
        public int CommentCounter { get; set; }
    }
}